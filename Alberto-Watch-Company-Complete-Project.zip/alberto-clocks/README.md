# Alberto Watch Company — Single Page Application

A responsive React/Vite implementation of the Alberto Watch Company eProject brief.

## Requirements covered
- Responsive single-page website
- Logo/brand header and navigation
- Products, Technology, Store Locator, Support, Gallery, About Us and Contact Us
- Product categories: Vintage, Luxury, Smart Watches and Technology
- Product filtering and complete product list
- Product quick-view popup with specifications and price
- Wishlist stored in browser localStorage
- Continuous bottom ticker with current date/time and HTML5 geolocation when permission is granted
- Visitor/wishlist indicator beside the logo area
- Hover/active navigation states and responsive mobile menu
- Gallery
- Contact form demo
- Attractive typography, animations and responsive layout

## Run in VS Code
1. Install Node.js LTS.
2. Open this folder in Visual Studio Code.
3. Open Terminal > New Terminal.
4. Run `npm install`.
5. Run `npm run dev`.
6. Open the localhost URL shown by Vite.

## Production build
`npm run build`

Then use `npm run preview` to preview the production build.

## Notes
The project uses remote Unsplash image URLs for the demo catalogue. Replace them with local licensed images if the final submission requires all assets to be self-contained/offline.
The store address, phone and email are demonstration details because the supplied brief does not provide real Alberto contact information.
The brief asks for a visitor count; this implementation uses a browser-side wishlist/visitor indicator rather than claiming a server-backed unique visitor database. For a true multi-user visitor counter, add a backend/database.
