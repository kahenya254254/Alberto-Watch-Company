# Alberto Watch Company — Project Report

## 1. Problem Definition
Alberto Watch Company is presented in the supplied project brief as a full-service watch repair, appraisal and retail store offering luxury timepieces and brands such as Michael Kors, Rolex, Citizen Eco-Drive and Bulova. The required solution is a responsive single-page website with product categories, product details, pricing, gallery, company information, contact details and interactive browser features.

## 2. Objectives
- Present Alberto's products in a structured digital catalogue.
- Allow users to browse product line-ups and view product details in a popup.
- Display watch prices and specifications.
- Provide technology, gallery, store, support, about and contact sections.
- Provide responsive navigation and visual interaction.
- Display a continuous date/time/location ticker using browser APIs.

## 3. Scope
The implementation is a frontend SPA. Product data is stored in JavaScript as a JSON-like array for simplicity. There is no real payment processing, authentication or server-side CRM because these are not specified in the brief.

## 4. Design Specification
### Architecture
React component-based SPA + Vite build tooling.

### Components
- Header: navigation and wishlist indicator.
- Home: hero and introduction.
- Products: category filters and catalogue.
- ProductCard: product summary.
- ProductModal: detailed popup.
- Technology, Gallery, Store, About, Contact and Support sections.
- Ticker: date, time and geolocation display.

### Data Model
Product fields: id, name, category, price, brand, movement, material, water, description and image.

## 5. User Flow
```text
Start
  |
  v
Home / Hero
  |
  +--> Products --> Select Category --> Product List --> Quick View --> Details
  |
  +--> Technology
  +--> Gallery
  +--> Store Locator
  +--> About Us
  +--> Contact Us --> Submit Enquiry
  +--> Support
  |
  v
Bottom ticker: Date + Time + Location
```

## 6. Data Flow Diagram — Level 0
```text
[Visitor]
   |
   | navigation / product selection / enquiry
   v
[React SPA]
   |          |        \--> [Browser Geolocation API]
   |        \--> [LocalStorage - Wishlist]
   v
[Product Data]
   |
   v
[Catalogue / Product Modal / Sections]
```

## 7. Test Data
| Test | Input/Action | Expected Result |
|---|---|---|
| T01 | Load homepage | Header, hero and navigation display |
| T02 | Click Products | Product section is displayed |
| T03 | Select Luxury | Only Luxury products display |
| T04 | Select Quick View | Modal opens with image/specs/price |
| T05 | Add wishlist | Indicator changes and item persists in localStorage |
| T06 | Refresh browser | Wishlist remains |
| T07 | Open mobile width | Navigation becomes mobile menu and grids adapt |
| T08 | Allow geolocation | Ticker shows approximate browser coordinates |
| T09 | Deny geolocation | Ticker remains usable with fallback text |
| T10 | Submit contact form | Demo success alert appears |
| T11 | npm run build | Production bundle is generated |

## 8. Installation Instructions
Install Node.js LTS, open the project in VS Code, run `npm install`, then `npm run dev`.

## 9. Assumptions
- Demonstration contact information is used because no real contact details are supplied in the brief.
- Product images are demonstration assets loaded from Unsplash.
- A real visitor count requires a backend service; the supplied frontend brief does not define a server/database mechanism.
- IE support is not guaranteed by modern React/Vite tooling; current Chrome, Edge, Firefox and Safari are the practical target browsers.

## 10. Deliverables
Source code, README, test data, installation instructions, project report, flow/data-flow diagrams and a production build configuration are included in this package.
