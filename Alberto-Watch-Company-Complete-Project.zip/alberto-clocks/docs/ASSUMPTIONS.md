# Assumptions
1. The supplied brief does not provide actual Alberto store contact details, so demo details are clearly used in the frontend.
2. The supplied brief asks for a visitor count but does not specify a backend. A production visitor counter should use a server/database rather than a browser-only counter.
3. The brief lists React/AngularJS among frontend technologies; this implementation chooses React because it is a natural fit for the requested single-page application.
4. Product data is kept in JavaScript to satisfy the JSON/TXT-style data-store requirement while keeping the project simple to run.
5. Product imagery is externally hosted demo imagery and should be replaced with licensed/local assets for a final commercial deployment.
