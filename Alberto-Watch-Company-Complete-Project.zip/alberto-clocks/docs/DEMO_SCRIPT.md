# Demo Video Script

1. Open the site and show the Alberto logo and responsive header.
2. Scroll through the hero and explain the service positioning.
3. Open Products and demonstrate category filters.
4. Open a product quick-view popup and point out price, movement, material and water resistance.
5. Add a product to wishlist and show the indicator.
6. Open Technology and Gallery.
7. Show Store Locator, About Us and Support.
8. Open Contact Us and submit the demo form.
9. Show the bottom ticker updating date/time and, if permission is granted, geolocation.
10. Resize the browser to demonstrate responsive behavior.
