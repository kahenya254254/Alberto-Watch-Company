# Test Cases

| ID | Area | Procedure | Expected |
|---|---|---|---|
| TC-01 | Navigation | Click each menu item | Correct section scrolls into view |
| TC-02 | Products | Click Vintage | Vintage catalogue is filtered |
| TC-03 | Products | Click All | All products return |
| TC-04 | Popup | Click Quick View | Popup displays selected product |
| TC-05 | Popup | Click close/X or background | Popup closes |
| TC-06 | Wishlist | Click heart | Wishlist count changes |
| TC-07 | Persistence | Refresh after wishlist | Wishlist state remains |
| TC-08 | Responsive | Resize to phone | Mobile menu and one-column layout work |
| TC-09 | Geolocation | Allow permission | Coordinates appear in ticker |
| TC-10 | Geolocation | Deny permission | Fallback remains visible |
| TC-11 | Contact | Submit valid form | Confirmation alert appears |
| TC-12 | Build | Run npm run build | Build completes without source errors |
